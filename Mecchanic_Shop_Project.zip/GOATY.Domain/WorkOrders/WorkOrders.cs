﻿
using GOATY.Domain.Common;

namespace GOATY.Domain.WorkOrders
{
    public sealed class WorkOrders : AuditableEntity
    {
        // decimal
        // DateTimeOffset
        // string
        // bool
        // Labor
        // List<RepairTask>
        // Enum
        // DateTimeOffset
        // Enum
        // Vehicle
    }
}
