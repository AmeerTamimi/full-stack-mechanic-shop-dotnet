﻿using MediatR;

namespace GOATY.Domain.Common
{
    public abstract class DomainEvent : INotification;
}
