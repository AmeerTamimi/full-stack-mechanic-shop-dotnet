﻿
namespace GOATY.Domain.Common.Constans
{
    public class GOATYConstans
    {
        public static decimal TaxRate = 0.15m;

        public static string SystemUser = "System";

        public static string MERO = "merooooooooo";
    }
}
