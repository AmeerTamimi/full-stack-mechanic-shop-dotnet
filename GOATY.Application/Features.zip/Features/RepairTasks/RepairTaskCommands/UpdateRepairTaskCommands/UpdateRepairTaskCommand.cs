﻿using GOATY.Application.Features.RepairTasks.RepairTaskCommands.CreateRepairTaskCommands;
using GOATY.Domain.Common.Enums;
using GOATY.Domain.Common.Results;
using MediatR;

namespace GOATY.Application.Features.RepairTasks.RepairTaskCommands.UpdateRepairTaskCommands
{
    public sealed record class UpdateRepairTaskCommand(
        Guid Id,
        string Name,
        string Description,
        TimeStamps TimeEstimated,
        decimal CostEstimated,
        decimal TechnicianCost,
        IReadOnlyList<PartRequirements> Parts) 
        : IRequest<Result<Updated>>;
}
