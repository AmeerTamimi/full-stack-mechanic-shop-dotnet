﻿using GOATY.Application.Common.Interfaces;
using GOATY.Domain.Common.Results;
using GOATY.Domain.Employees;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Hybrid;

namespace GOATY.Application.Features.Employees.EmployeeCommands.DeleteEmployeeCommand
{
    public sealed class DeleteEmployeeCommandHandler(IAppDbContext context , HybridCache cache) : IRequestHandler<DeleteEmployeeCommand, Result<Deleted>>
    {
        public async Task<Result<Deleted>> Handle(DeleteEmployeeCommand request, CancellationToken ct)
        {
            var employeeId = request.Id;
            var employee = await context.Employees.SingleOrDefaultAsync(
                                                        emp => emp.Id == employeeId,
                                                        ct
                                                   );

            if (employee is null)
            {
                return Error.NotFound(
                                code: "Employee.NotFound",
                                description: $"Employee With Id {employeeId} Was Not Found."
                            );
            }

            context.Employees.Remove(employee); // might make it soft delete here
            await context.SaveChangesAsync(ct);

            await cache.RemoveByTagAsync("employees");

            return Result.Deleted;
        }
    }
}
