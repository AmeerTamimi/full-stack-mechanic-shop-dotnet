﻿using GOATY.Application.Common.Interfaces;
using GOATY.Application.Features.Parts.DTOs;
using GOATY.Application.Features.Parts.Mapping;
using GOATY.Application.Features.RepairTasks.Mapping;
using GOATY.Domain.Common.Results;
using GOATY.Domain.Parts;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Hybrid;

namespace GOATY.Application.Features.Parts.PartsCommands.CreatePartCommands
{
    public sealed class CreatePartCommandHandler(IAppDbContext context , HybridCache cache) : IRequestHandler<CreatePartCommand, Result<PartDto>>
    {
        public async Task<Result<PartDto>> Handle(CreatePartCommand request, CancellationToken ct)
        {
            var name = request.Name;
            var result = Part.Create(Guid.NewGuid(), name, request.Cost, request.Quantity);

            if (!result.IsSuccess)
            {
                return result.Errors;
            }

            var nameExists = await context.Parts.AnyAsync(p => p.Name == name , ct);

            if (nameExists)
            {
                // warning log
                return Error.Conflict(
                                code: "Part.Name.Conflict",
                                description: $"The Part Name {name} Already Exists."
                            );
            }

            var newPart = result.Value;

            await context.Parts.AddAsync(newPart);
            await context.SaveChangesAsync(ct);

            await cache.RemoveByTagAsync("parts", ct);

            return newPart.ToDto();
        }
    }
}
