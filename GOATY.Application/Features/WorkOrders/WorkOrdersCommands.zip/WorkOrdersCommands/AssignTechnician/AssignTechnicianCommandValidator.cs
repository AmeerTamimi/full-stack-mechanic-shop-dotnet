﻿using FluentValidation;

namespace GOATY.Application.Features.WorkOrders.WorkOrdersCommands.AssignTechnician
{
    public sealed class AssignTechnicianCommandValidator : AbstractValidator<AssignTechnicianCommand>
    {
        public AssignTechnicianCommandValidator()
        {
            
        }
    }
}
