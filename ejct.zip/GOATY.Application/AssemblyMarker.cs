﻿namespace GOATY.Application
{
    public sealed class AssemblyMarker;
}
